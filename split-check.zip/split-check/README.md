# Split the check

Photo of a receipt in, one link out. Friends scan, tap what they ate, pay you.

## Status: live

Published and verified at **https://cmcgrew.github.io/split/**, paying
**@Christopher-McGrew**. `config.json` is filled in.

Remaining step: upload `SKILL.md`, `encode.js`, and `config.json` to Claude as a
Skill. Then you're done — you never touch `split.html` again.

Optional: set `payeeName` in `config.json` to your first name. The button then
reads "Pay Chris $20.98" instead of "Pay $20.98 with Venmo", which is how a
guest notices if money is heading to the wrong person.

### Verification performed

- Deployed file is byte-for-byte identical to the build (sha `a0114abd897a242a`,
  45,745 bytes)
- QR generated from the deployed bytes decodes back to the exact production URL
- Bare URL correctly shows "No check loaded"
- No personal data anywhere in the published file

## Sharing it with other people

`split.html` contains no personal data — no handle, no name, nothing. The payee
travels inside each link. So:

- **Your friends can point at your published page.** They copy the Skill, set
  their own `venmo` in `config.json`, and leave `baseUrl` pointing at your URL.
  You cannot see their bills: fragments never reach your host, so nothing about
  their dinners appears in your logs. There is no shared state to collide over.
- **Or they publish their own copy.** Also fine, and it means they aren't
  depending on your hosting staying up.

Either way each person edits exactly one line: `venmo`.

### When someone else picks up the tab

Just say so — "Dana paid tonight". The Skill overrides the payee for that bill
without touching your config, and the button reads "Pay Dana $18.20" so nobody
sends money to the wrong person.

### Handles the encoder accepts

`@Chris-McGrew`, `Chris-McGrew`, `venmo.com/u/chris_m`, and
`https://www.venmo.com/Sarah-Lee-99?txn=pay` all normalize correctly. It rejects
display names like `Chris McGrew` with an explanation, because Venmo usernames
are 5–30 characters and allow only letters, numbers, `-` and `_`.

## Every time after that

> *[attach receipt photo]* split this check

Claude reads it, assumes a 20% tip if the receipt doesn't show one, and shows
you the full itemization to confirm — one tap for "Looks good," or tell it
what to change. Then it hands you a link as a file with a tappable "Open your
host view" button, so nothing gets retyped by hand. Open it, tap **Show QR**,
hold up your phone.

## How it works

The bill is deflate-compressed, base64url-encoded, and lives in the URL fragment
(`#z...`). Fragments are never sent to the server, so the bill is not in anyone's
access logs and there is no database. A 40-item, $1,431 receipt fits in a
908-character URL and a 101×101 QR code.

`split.html` is a static shell. Loaded without a fragment it shows nothing.

## Host view

Append `.h` to the URL: `https://.../split.html#z<data>.h`

Adds a QR button, a copy-guest-link button, and a ledger to tick people off as
their Venmo payments land, with a running "still owed to you" figure. Guests
never see it. State is stored locally on your device only.

## Paid add-ons

If a receipt shows a modifier with its own charge — "Add Feta Cheese $0.95" —
it folds into that item's price and shows as a small label under the name:

```
Buffalo Chicken Salad Wrap        $9.44
+ Feta Cheese ($0.95)
```

Free modifiers ("No Tomatoes", "Ranch Dressing") are left off entirely — they
don't change anyone's total, so they'd only be noise on the guest's phone.

If two people order what's nominally the "same" dish but one adds something
that costs money, they're no longer a single `qty: 2` line — they show as two
separate rows, each with its own price. Averaging them together would either
overcharge the plain order or undercharge the modified one.

## Splitting evenly

Say "split it 8 ways" and the whole bill divides equally instead of by item.
Guests see the itemization read-only plus their share, and nothing to tap but
Pay. The host ledger becomes eight tick boxes, one per person.

The per-person share rounds up to the cent so you are never left short — with 8
people on a $176.69 bill that is $22.09 each and $0.03 more than the bill in
total. The host view says so.

There is no guest-side toggle for this, on purpose. If each guest could pick
their own split, the shares would not add up to the bill. Splitting evenly is a
table decision, so it lives in the link you generate.

## What guests see

- Tap an item to claim it
- Items with a quantity get a stepper (`1 of 2`)
- Any item can be split N ways (`½`, `⅓`, `¼`, `⅕`, `⅙`, `⅛`) on the item itself
- A pinned bar shows their running total; tap it for the tax and tip breakdown
- The button opens Venmo prefilled, with the claimed items in the note

Tax and tip are allocated proportionally to what each person claims, computed on
their device. If the table under-claims, the shortfall lands on the host.

## Caveats

- **Venmo's amount prefill is inconsistent across app versions.** The amount is
  shown large above the button and there's a *Copy amount* button, so a failed
  prefill costs three seconds.
- **No shared state.** Two people can claim the same steak, and nobody is forced
  to claim the appetizer. Everyone is at the same table; use the host ledger to
  reconcile. If double-claiming turns out to be a real problem, the fix is a
  Cloudflare Worker with KV — about 60 lines — and the page's data model already
  supports it.
- Anyone with the link can see the bill. Same as an unlisted Google Doc.
- Don't add analytics or CDN scripts to `split.html`. Anything running on the
  page can read the fragment.

## Rebuilding split.html

`split.src.html` is the source; the QR library is inlined at build time.

```bash
node -e "const f=require('fs');f.writeFileSync('split.html',
  f.readFileSync('split.src.html','utf8').replace('/*QRLIB*/',()=>f.readFileSync('qr.min.js','utf8')))"
```

If you ever rebuild, re-upload the result to the `split` repo as `index.html`.

QR library: qrcode-generator by Kazuhiko Arase, MIT.
