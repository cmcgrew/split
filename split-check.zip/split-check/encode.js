#!/usr/bin/env node
/**
 * split-the-bill encoder
 * Usage: node encode.js bill.json [--base https://you.github.io/split/]
 *
 * Reads a bill JSON file, validates the arithmetic, and prints the share URL.
 * Works with any itemized receipt: restaurants, groceries, hardware stores,
 * group orders, shared online carts.
 * Payload format: <base>#z<base64url(deflateRaw(json))>
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
  } catch (e) {
    return {};
  }
}

const b64url = (buf) =>
  buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

const r2 = (n) => Math.round(n * 100) / 100;

/**
 * People will hand us all of these:
 *   "@chris-mcgrew"  "venmo.com/u/chris-mcgrew"  " Chris-McGrew "
 *   "https://venmo.com/chris-mcgrew?txn=pay"     "Chris McGrew"  <- display name, wrong
 * Normalize what we can; refuse the rest loudly rather than build a dead link.
 */
function normalizeHandle(raw) {
  if (raw == null) return { error: 'No Venmo username set.' };
  let h = String(raw).trim();

  h = h.replace(/^https?:\/\//i, '').replace(/^www\./i, '');
  h = h.replace(/^venmo\.com\/(u\/)?/i, '');
  h = h.split(/[?#/]/)[0];
  h = h.replace(/^@+/, '').trim();

  if (!h) return { error: 'No Venmo username set.' };
  if (/\s/.test(h))
    return {
      error:
        `"${raw}" has a space in it, so it looks like a display name rather than a ` +
        `username. The username is the one under your photo in the Venmo app, ` +
        `starting with @.`,
    };
  if (!/^[A-Za-z0-9_-]+$/.test(h))
    return { error: `"${h}" has characters Venmo does not allow. Only letters, numbers, - and _.` };
  if (h.length < 5 || h.length > 30)
    return { error: `"${h}" is ${h.length} characters. Venmo usernames are 5 to 30.` };

  return { handle: h, changed: h !== String(raw).trim() };
}

/**
 * Fees that apply to the WHOLE bill — delivery, service, bag, resort,
 * booking, environmental. A fee attached to one single item is not one of
 * these; that folds into the item's price as an add-on instead.
 *
 * Accepts a plain number, or a list of {name, amount} so the parsed-bill
 * printout can show the host what each one was. Only the total travels in
 * the link.
 */
function sumFees(raw) {
  if (raw == null) return { total: 0, lines: [] };
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) throw new Error('"fees" is not a number.');
    return { total: r2(raw), lines: [] };
  }
  if (!Array.isArray(raw))
    throw new Error('"fees" must be a number, or a list of {name, amount}.');
  const lines = raw.map((f, i) => {
    const amt = Number(f && f.amount);
    if (!Number.isFinite(amt))
      throw new Error(`fees[${i}] needs a numeric "amount".`);
    return { name: String((f && f.name) || 'Fee').slice(0, 32), amount: r2(amt) };
  });
  return { total: r2(lines.reduce((a, l) => a + l.amount, 0)), lines };
}

function build(bill) {
  const items = bill.items.map((it) => {
    const row = [String(it.name).slice(0, 32), r2(it.price), it.qty ?? 1];
    // index 3 (shared) must be present if addons follow, so the array stays
    // positional. 0 = not shared, distinct from "absent".
    if (it.shared || it.addons) row.push(it.shared ? 1 : 0);
    if (it.addons) row.push(String(it.addons).slice(0, 40));
    return row;
  });

  const subtotal = r2(items.reduce((a, [, p, q]) => a + p * q, 0));

  const norm = normalizeHandle(bill.venmo);
  if (norm.error) throw new Error('Venmo username: ' + norm.error);

  if (bill.splitEvenly != null) {
    const n = Number(bill.splitEvenly);
    if (!Number.isInteger(n) || n < 2 || n > 50)
      throw new Error(
        `splitEvenly must be a whole number of people between 2 and 50 (got ${bill.splitEvenly}).`
      );
  }

  const fees = sumFees(bill.fees);

  const payload = {
    v: 1,
    // "merchant" is the generic name; "restaurant" still works for old bills
    r: bill.merchant || bill.restaurant || '',
    h: norm.handle,
    s: subtotal,
    x: r2(bill.tax || 0),
    p: r2(bill.tip || 0),
    i: items,
  };
  // omitted entirely when there are none, so ordinary bills stay short
  if (fees.total) payload.f = fees.total;
  if (bill.splitEvenly) payload.e = Math.floor(bill.splitEvenly);
  if (bill.payeeName) payload.y = String(bill.payeeName).slice(0, 20);
  if (bill.date) payload.d = bill.date;
  if (bill.note) payload.m = bill.note;
  return { payload, subtotal, fees, normalized: norm.changed };
}

function validate(bill, payload, subtotal) {
  const problems = [];
  const computed = r2(subtotal + payload.x + payload.p + (payload.f || 0));

  if (bill.statedSubtotal != null && Math.abs(bill.statedSubtotal - subtotal) > 0.02) {
    problems.push(
      `Items add to $${subtotal.toFixed(2)} but the receipt says the subtotal is ` +
        `$${Number(bill.statedSubtotal).toFixed(2)} ` +
        `(off by $${Math.abs(bill.statedSubtotal - subtotal).toFixed(2)}).`
    );
  }
  if (bill.statedTotal != null && Math.abs(bill.statedTotal - computed) > 0.02) {
    problems.push(
      `Items + tax + tip${payload.f ? ' + fees' : ''} = $${computed.toFixed(2)} ` +
        `but the receipt total is ` +
        `$${Number(bill.statedTotal).toFixed(2)} ` +
        `(off by $${Math.abs(bill.statedTotal - computed).toFixed(2)}).`
    );
  }
  return { problems, computed };
}

function encode(payload) {
  const json = JSON.stringify(payload);
  const deflated = zlib.deflateRawSync(Buffer.from(json, 'utf8'), { level: 9 });
  return { frag: 'z' + b64url(deflated), rawLen: json.length, packLen: deflated.length };
}

const b64urlToBuffer = (s) => {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Buffer.from(s, 'base64');
};

/**
 * Decompress what we just compressed and diff it against the source payload,
 * exactly as the guest's browser will. Catches bugs in this tool before a
 * link ever gets printed. It cannot catch damage done after that — a bad
 * copy-paste, a wrapped terminal line, a messaging app mangling the string —
 * that happens downstream of here, after this check has already passed.
 */
function selfCheck(frag, payload) {
  const expected = JSON.stringify(payload);
  let got;
  try {
    got = zlib.inflateRawSync(b64urlToBuffer(frag.slice(1))).toString('utf8');
  } catch (e) {
    throw new Error(
      'Internal error: the link this tool just built does not decompress ' +
        `(${e.message}). Do not send it — please report this bug.`
    );
  }
  if (got !== expected) {
    throw new Error(
      'Internal error: decompressing the link this tool just built does not ' +
        'reproduce the bill. Do not send it — please report this bug.'
    );
  }
}

function main() {
  const args = process.argv.slice(2);
  const file = args.find((a) => !a.startsWith('--'));
  const baseArg = args.find((a) => a.startsWith('--base='));
  const base = baseArg
    ? baseArg.split('=').slice(1).join('=')
    : loadConfig().baseUrl || 'https://REPLACE-ME/';
  if (base.indexOf('REPLACE-ME') >= 0) {
    console.error('\nbaseUrl is not set. Publish the page and put its URL in config.json.\n');
    process.exit(2);
  }

  if (!file) {
    console.error('usage: node encode.js bill.json [--base=https://host/index.html]');
    process.exit(1);
  }

  const cfg = loadConfig();
  const bill = JSON.parse(fs.readFileSync(file, 'utf8'));
  const vArg = args.find((a) => a.startsWith('--venmo='));
  const nArg = args.find((a) => a.startsWith('--payee-name='));

  // precedence: command line > this bill's json > config.json
  const sArg = args.find((a) => a.startsWith('--split-evenly='));
  if (sArg) bill.splitEvenly = Number(sArg.slice('--split-evenly='.length));
  if (vArg) bill.venmo = vArg.slice('--venmo='.length);
  else if (!bill.venmo) bill.venmo = cfg.venmo;
  if (nArg) bill.payeeName = nArg.slice('--payee-name='.length);
  else if (!bill.payeeName) bill.payeeName = cfg.payeeName || '';

  let built;
  try {
    built = build(bill);
  } catch (e) {
    console.error('\n' + e.message + '\n');
    process.exit(2);
  }
  const { payload, subtotal, fees, normalized } = built;
  const { problems, computed } = validate(bill, payload, subtotal);
  const { frag, rawLen, packLen } = encode(payload);

  try {
    selfCheck(frag, payload);
  } catch (e) {
    console.error('\n' + e.message + '\n');
    process.exit(2);
  }

  const url = base + '#' + frag;

  console.log('--- parsed bill ---');
  console.log(`merchant   : ${payload.r}`);
  console.log(`pays to    : @${payload.h}${payload.y ? ' (' + payload.y + ')' : ''}` +
    (normalized ? `   [cleaned up from "${bill.venmo}"]` : ''));
  payload.i.forEach(([n, p, q, sh, ad]) =>
    console.log(
      `  ${q} x $${p.toFixed(2).padStart(7)}  ${n}` +
        `${sh ? '   [shared]' : ''}${ad ? '   (' + ad + ')' : ''}`
    )
  );
  console.log(`subtotal   : $${subtotal.toFixed(2)}`);
  console.log(`tax        : $${payload.x.toFixed(2)}`);
  console.log(`tip        : $${payload.p.toFixed(2)}`);
  if (payload.f) {
    console.log(`fees       : $${payload.f.toFixed(2)}`);
    fees.lines.forEach((l) =>
      console.log(`             $${l.amount.toFixed(2).padStart(7)}  ${l.name}`)
    );
  }
  console.log(`total      : $${computed.toFixed(2)}`);
  if (payload.e) {
    const share = Math.ceil((computed / payload.e) * 100) / 100;
    const over = r2(share * payload.e - computed);
    console.log(`SPLIT EVENLY ${payload.e} ways -> $${share.toFixed(2)} each`);
    if (over > 0)
      console.log(`  (rounded up; you collect $${over.toFixed(2)} more than the bill)`);
  }
  console.log('');

  if (problems.length) {
    console.log('!!! CHECK THESE BEFORE SENDING !!!');
    problems.forEach((p) => console.log('  - ' + p));
    console.log('');
  } else {
    console.log('arithmetic checks out.');
  }

  console.log(`json ${rawLen}b -> packed ${packLen}b -> url ${url.length} chars`);
  if (url.length > 1800) {
    console.log('WARNING: url is long; QR will be dense. Shorten item names.');
  }
  console.log('');
  console.log(`guest url: ${url}`);
  console.log(`host url : ${url}.h`);

  const outArg = args.find((a) => a.startsWith('--out='));
  if (outArg) {
    const outPath = outArg.slice('--out='.length);
    if (problems.length) {
      console.error(
        '\nNot writing link file: arithmetic problems above must be resolved first.\n'
      );
      process.exit(2);
    }
    const hostUrl = url + '.h';
    let content;
    if (outPath.endsWith('.html')) {
      content = `<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    background:#f2f2f7;margin:0;padding:24px 16px;color:#000}
  .card{background:#fff;border-radius:14px;padding:20px;margin-bottom:14px;
    box-shadow:0 1px 3px rgba(0,0,0,.07)}
  .card p{margin:0 0 12px;font-size:14px;color:#6c6c70;line-height:1.4}
  a.btn{display:block;text-align:center;background:#0a7cff;color:#fff;
    font-weight:600;font-size:17px;text-decoration:none;border-radius:12px;
    padding:14px;letter-spacing:-.2px}
  a.btn.secondary{background:#e5e5ea;color:#000}
</style></head><body>
  <div class="card">
    <p>Open this yourself — it has the QR code and the payment tracker.</p>
    <a class="btn" href="${hostUrl}">HOST LINK</a>
  </div>
  <div class="card">
    <p>Guests get this automatically when they scan your QR code from the
    host view. Send it yourself only if you're not using the QR.</p>
    <a class="btn secondary" href="${url}">GUEST LINK</a>
  </div>
</body></html>`;
    } else {
      content =
        `# Your split-the-bill link\n\n` +
        `**[HOST LINK](${hostUrl})**\n` +
        `Open this yourself — it has the QR code and the payment tracker.\n\n` +
        `**[GUEST LINK](${url})**\n` +
        `Guests get this automatically when they scan your QR code from the ` +
        `host view. You only need to send it yourself if you're not using the QR.\n`;
    }
    fs.writeFileSync(outPath, content);
    console.log(`\nwrote link file: ${outPath}`);
  }
}

if (require.main === module) main();
module.exports = { build, validate, encode, normalizeHandle, selfCheck };
