#!/usr/bin/env node
/**
 * splitcheck encoder
 * Usage: node encode.js bill.json [--base https://you.github.io/split/]
 *
 * Reads a bill JSON file, validates the arithmetic, and prints the share URL.
 * Payload format: <base>#z<base64url(deflateRaw(json))>
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
  } catch (e) {
    return {};
  }
}

const b64url = (buf) =>
  buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

const r2 = (n) => Math.round(n * 100) / 100;

/**
 * People will hand us all of these:
 *   "@chris-mcgrew"  "venmo.com/u/chris-mcgrew"  " Chris-McGrew "
 *   "https://venmo.com/chris-mcgrew?txn=pay"     "Chris McGrew"  <- display name, wrong
 * Normalize what we can; refuse the rest loudly rather than build a dead link.
 */
function normalizeHandle(raw) {
  if (raw == null) return { error: 'No Venmo username set.' };
  let h = String(raw).trim();

  h = h.replace(/^https?:\/\//i, '').replace(/^www\./i, '');
  h = h.replace(/^venmo\.com\/(u\/)?/i, '');
  h = h.split(/[?#/]/)[0];
  h = h.replace(/^@+/, '').trim();

  if (!h) return { error: 'No Venmo username set.' };
  if (/\s/.test(h))
    return {
      error:
        `"${raw}" has a space in it, so it looks like a display name rather than a ` +
        `username. The username is the one under your photo in the Venmo app, ` +
        `starting with @.`,
    };
  if (!/^[A-Za-z0-9_-]+$/.test(h))
    return { error: `"${h}" has characters Venmo does not allow. Only letters, numbers, - and _.` };
  if (h.length < 5 || h.length > 30)
    return { error: `"${h}" is ${h.length} characters. Venmo usernames are 5 to 30.` };

  return { handle: h, changed: h !== String(raw).trim() };
}

function build(bill) {
  const items = bill.items.map((it) => {
    const row = [String(it.name).slice(0, 32), r2(it.price), it.qty ?? 1];
    // index 3 (shared) must be present if addons follow, so the array stays
    // positional. 0 = not shared, distinct from "absent".
    if (it.shared || it.addons) row.push(it.shared ? 1 : 0);
    if (it.addons) row.push(String(it.addons).slice(0, 40));
    return row;
  });

  const subtotal = r2(items.reduce((a, [, p, q]) => a + p * q, 0));

  const norm = normalizeHandle(bill.venmo);
  if (norm.error) throw new Error('Venmo username: ' + norm.error);

  if (bill.splitEvenly != null) {
    const n = Number(bill.splitEvenly);
    if (!Number.isInteger(n) || n < 2 || n > 50)
      throw new Error(
        `splitEvenly must be a whole number of people between 2 and 50 (got ${bill.splitEvenly}).`
      );
  }

  const payload = {
    v: 1,
    r: bill.restaurant || '',
    h: norm.handle,
    s: subtotal,
    x: r2(bill.tax || 0),
    p: r2(bill.tip || 0),
    i: items,
  };
  if (bill.splitEvenly) payload.e = Math.floor(bill.splitEvenly);
  if (bill.payeeName) payload.y = String(bill.payeeName).slice(0, 20);
  if (bill.date) payload.d = bill.date;
  if (bill.note) payload.m = bill.note;
  return { payload, subtotal, normalized: norm.changed };
}

function validate(bill, payload, subtotal) {
  const problems = [];
  const computed = r2(subtotal + payload.x + payload.p);

  if (bill.statedSubtotal != null && Math.abs(bill.statedSubtotal - subtotal) > 0.02) {
    problems.push(
      `Items add to $${subtotal.toFixed(2)} but the receipt says the subtotal is ` +
        `$${Number(bill.statedSubtotal).toFixed(2)} ` +
        `(off by $${Math.abs(bill.statedSubtotal - subtotal).toFixed(2)}).`
    );
  }
  if (bill.statedTotal != null && Math.abs(bill.statedTotal - computed) > 0.02) {
    problems.push(
      `Items + tax + tip = $${computed.toFixed(2)} but the receipt total is ` +
        `$${Number(bill.statedTotal).toFixed(2)} ` +
        `(off by $${Math.abs(bill.statedTotal - computed).toFixed(2)}).`
    );
  }
  return { problems, computed };
}

function encode(payload) {
  const json = JSON.stringify(payload);
  const deflated = zlib.deflateRawSync(Buffer.from(json, 'utf8'), { level: 9 });
  return { frag: 'z' + b64url(deflated), rawLen: json.length, packLen: deflated.length };
}

const b64urlToBuffer = (s) => {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Buffer.from(s, 'base64');
};

/**
 * Decompress what we just compressed and diff it against the source payload,
 * exactly as the guest's browser will. Catches bugs in this tool before a
 * link ever gets printed. It cannot catch damage done after that — a bad
 * copy-paste, a wrapped terminal line, a messaging app mangling the string —
 * that happens downstream of here, after this check has already passed.
 */
function selfCheck(frag, payload) {
  const expected = JSON.stringify(payload);
  let got;
  try {
    got = zlib.inflateRawSync(b64urlToBuffer(frag.slice(1))).toString('utf8');
  } catch (e) {
    throw new Error(
      'Internal error: the link this tool just built does not decompress ' +
        `(${e.message}). Do not send it — please report this bug.`
    );
  }
  if (got !== expected) {
    throw new Error(
      'Internal error: decompressing the link this tool just built does not ' +
        'reproduce the bill. Do not send it — please report this bug.'
    );
  }
}

function main() {
  const args = process.argv.slice(2);
  const file = args.find((a) => !a.startsWith('--'));
  const baseArg = args.find((a) => a.startsWith('--base='));
  const base = baseArg
    ? baseArg.split('=').slice(1).join('=')
    : loadConfig().baseUrl || 'https://REPLACE-ME/';
  if (base.indexOf('REPLACE-ME') >= 0) {
    console.error('\nbaseUrl is not set. Publish split.html and put its URL in config.json.\n');
    process.exit(2);
  }

  if (!file) {
    console.error('usage: node encode.js bill.json [--base=https://host/split.html]');
    process.exit(1);
  }

  const cfg = loadConfig();
  const bill = JSON.parse(fs.readFileSync(file, 'utf8'));
  const vArg = args.find((a) => a.startsWith('--venmo='));
  const nArg = args.find((a) => a.startsWith('--payee-name='));

  // precedence: command line > this bill's json > config.json
  const sArg = args.find((a) => a.startsWith('--split-evenly='));
  if (sArg) bill.splitEvenly = Number(sArg.slice('--split-evenly='.length));
  if (vArg) bill.venmo = vArg.slice('--venmo='.length);
  else if (!bill.venmo) bill.venmo = cfg.venmo;
  if (nArg) bill.payeeName = nArg.slice('--payee-name='.length);
  else if (!bill.payeeName) bill.payeeName = cfg.payeeName || '';

  let built;
  try {
    built = build(bill);
  } catch (e) {
    console.error('\n' + e.message + '\n');
    process.exit(2);
  }
  const { payload, subtotal, normalized } = built;
  const { problems, computed } = validate(bill, payload, subtotal);
  const { frag, rawLen, packLen } = encode(payload);

  try {
    selfCheck(frag, payload);
  } catch (e) {
    console.error('\n' + e.message + '\n');
    process.exit(2);
  }

  const url = base + '#' + frag;

  console.log('--- parsed bill ---');
  console.log(`restaurant : ${payload.r}`);
  console.log(`pays to    : @${payload.h}${payload.y ? ' (' + payload.y + ')' : ''}` +
    (normalized ? `   [cleaned up from "${bill.venmo}"]` : ''));
  payload.i.forEach(([n, p, q, sh, ad]) =>
    console.log(
      `  ${q} x $${p.toFixed(2).padStart(7)}  ${n}` +
        `${sh ? '   [shared]' : ''}${ad ? '   (' + ad + ')' : ''}`
    )
  );
  console.log(`subtotal   : $${subtotal.toFixed(2)}`);
  console.log(`tax        : $${payload.x.toFixed(2)}`);
  console.log(`tip        : $${payload.p.toFixed(2)}`);
  console.log(`total      : $${computed.toFixed(2)}`);
  if (payload.e) {
    const share = Math.ceil((computed / payload.e) * 100) / 100;
    const over = r2(share * payload.e - computed);
    console.log(`SPLIT EVENLY ${payload.e} ways -> $${share.toFixed(2)} each`);
    if (over > 0)
      console.log(`  (rounded up; you collect $${over.toFixed(2)} more than the bill)`);
  }
  console.log('');

  if (problems.length) {
    console.log('!!! CHECK THESE BEFORE SENDING !!!');
    problems.forEach((p) => console.log('  - ' + p));
    console.log('');
  } else {
    console.log('arithmetic checks out.');
  }

  console.log(`json ${rawLen}b -> packed ${packLen}b -> url ${url.length} chars`);
  if (url.length > 1800) {
    console.log('WARNING: url is long; QR will be dense. Shorten item names.');
  }
  console.log('');
  console.log(`guest url: ${url}`);
  console.log(`host url : ${url}.h`);

  const outArg = args.find((a) => a.startsWith('--out='));
  if (outArg) {
    const outPath = outArg.slice('--out='.length);
    if (problems.length) {
      console.error(
        '\nNot writing link file: arithmetic problems above must be resolved first.\n'
      );
      process.exit(2);
    }
    const hostUrl = url + '.h';
    const md =
      `# Your Split-the-Check link\n\n` +
      `**[HOST LINK](${hostUrl})**\n` +
      `Open this yourself — it has the QR code and the payment tracker.\n\n` +
      `**[GUEST LINK](${url})**\n` +
      `Guests get this automatically when they scan your QR code from the ` +
      `host view. You only need to send it yourself if you're not using the QR.\n`;
    fs.writeFileSync(outPath, md);
    console.log(`\nwrote link file: ${outPath}`);
  }
}

if (require.main === module) main();
module.exports = { build, validate, encode, normalizeHandle, selfCheck };
